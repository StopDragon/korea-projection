#!/bin/bash
# tcc803x 내비용 88x2bu.ko를 이 묶음으로 다시 빌드한다. Korea Projection 1.8.1의 drv/tcc803x-a/88x2bu.ko와 같은 방법이다.
# 쓰는 법(리눅스 x86_64에서): KTAR=linux-3.18.24.tar.xz TC=arm-eabi-4.7폴더 bash build-tcc803x.sh
# CARCFG는 차의 커널 설정이다(기본: 이 묶음의 tcc803x/kernel.config). sha256으로 같은 파일인지 확인한다.
# 같은 md5를 얻으려면 커널·드라이버를 아래 경로(K, D)에 둬야 한다. .ko에 빌드 경로 문자열이 들어가기 때문이다.
set -euo pipefail
B=$(cd "$(dirname "$0")" && pwd)
KTAR=${KTAR:?kernel.org linux-3.18.24.tar.xz 경로를 KTAR로 주세요}
TC=${TC:?arm-eabi-4.7 툴체인 폴더(bin/arm-eabi-gcc가 있는 곳)를 TC로 주세요}
CARCFG=${CARCFG:-$B/tcc803x/kernel.config}
K=${K:-/work/t803/k-kp-h2/linux-3.18.24}
D=${D:-/work/t803/d-kp-h2-pkp}
KSHA=ed54cf8c3ac6b95fc17b07b3a236bc42719c96fee08fe696cabfb5b8e07f8c1b
CSHA=d35af8a0e9d098a47720ea66de594f21691d3d9608ce388ed199e0a5f82f9913
CC_PREFIX=$TC/bin/arm-eabi-

echo "$KSHA  $KTAR" | sha256sum -c --status || { echo "커널 sha256이 다릅니다"; exit 1; }
echo "$CSHA  $CARCFG" | sha256sum -c --status || { echo "차 커널 설정 sha256이 다릅니다"; exit 1; }
[ ! -e "$K" ] && [ ! -e "$D" ] || { echo "$K 또는 $D가 이미 있습니다. 지우고 다시 하세요"; exit 1; }

echo "== 1. 커널 준비(kernel.org 3.18.24 + 헤더 패치 + 차 설정)"
mkdir -p "$(dirname "$K")"
tar -xJf "$KTAR" -C "$(dirname "$K")"
# 차의 TCC803X 기계 항목이 select하던 것(kernel.org에 없음)을 Kconfig 끝에 붙여 살린다
{ echo; echo "# kp: 차의 TCC803X 기계 항목이 select하던 것(kernel.org에 없음). 빌드 트리에만 붙인다"
  echo "config KP_TCC803X_LAYOUT"; echo "	def_bool y"
  for s in ARCH_DMA_ADDR_T_64BIT ZONE_DMA PINCTRL PINMUX PINCONF PM_GENERIC_DOMAINS PM_OPP USB_OTG; do echo "	select $s"; done; } >> "$K/arch/arm/Kconfig"
bash "$B/scripts/hdr-patch.sh" "$K"
bash "$B/scripts/hdr-patch-803x.sh" "$K"
cp "$CARCFG" "$K/.config"
# gcc 4.7에는 -fstack-protector-strong이 없다. REGULAR도 같은 __stack_chk_* 기호를 쓴다
"$K/scripts/config" --file "$K/.config" --disable CC_STACKPROTECTOR_STRONG --enable CC_STACKPROTECTOR_REGULAR
# LOCALVERSION은 차 설정에 "-tcc"로 들어 있어 따로 주지 않는다
make -s -C "$K" ARCH=arm CROSS_COMPILE=$CC_PREFIX olddefconfig
make -s -C "$K" ARCH=arm CROSS_COMPILE=$CC_PREFIX -j8 modules_prepare >/dev/null 2>&1 || { echo "modules_prepare 실패"; exit 2; }
[ "$(cat "$K/include/config/kernel.release")" = "3.18.24-tcc" ] || { echo "kernel.release가 다릅니다"; exit 2; }

echo "== 2. 드라이버(cilynx/rtl88x2bu fc158d1f + kp-protect 적용본)"
mkdir -p "$(dirname "$D")"
cp -a "$B/tcc803x/rtl88x2bu" "$D"
bash "$B/scripts/kp-protect.sh" "$D"   # 이미 적용돼 있어 바뀌지 않는다(확인만)
make -C "$D" -j8 ARCH=arm CROSS_COMPILE=$CC_PREFIX KSRC=$K KVER=3.18.24-tcc EXTRA_CFLAGS="-g" > /tmp/driver-build-tcc803x.log 2>&1 \
  || { tail -30 /tmp/driver-build-tcc803x.log; exit 2; }
echo "md5: $(md5sum "$D/88x2bu.ko" | cut -d' ' -f1)  (1.8.1 패키지: f5647f3100b02ec45834785b419c87ec, 시각 문자열을 고정해야 같아짐: README 참고)"
