#!/bin/bash
# tcc897x(니로 등) 내비용 88x2bu.ko를 이 묶음으로 다시 빌드한다. Korea Projection 1.8.0의 drv/tcc897x/88x2bu.ko와 같은 방법이다.
# 쓰는 법(리눅스 x86_64에서): KTAR=linux-3.18.24.tar.xz TC=arm-eabi-4.7폴더 bash build-tcc897x.sh
# 같은 md5를 얻으려면 커널·드라이버를 아래 경로(K, D)에 둬야 한다. .ko에 빌드 경로 문자열이 들어가기 때문이다.
set -euo pipefail
B=$(cd "$(dirname "$0")" && pwd)
KTAR=${KTAR:?kernel.org linux-3.18.24.tar.xz 경로를 KTAR로 주세요}
TC=${TC:?arm-eabi-4.7 툴체인 폴더(bin/arm-eabi-gcc가 있는 곳)를 TC로 주세요}
K=${K:-/work/src/linux-3.18.24}
D=${D:-/work/kp/niro-drv}
KSHA=ed54cf8c3ac6b95fc17b07b3a236bc42719c96fee08fe696cabfb5b8e07f8c1b
export PATH=$TC/bin:$PATH
MK="make -C $K ARCH=arm CROSS_COMPILE=arm-eabi- LOCALVERSION=-tcc"

echo "$KSHA  $KTAR" | sha256sum -c --status || { echo "커널 sha256이 다릅니다"; exit 1; }
[ ! -e "$K" ] && [ ! -e "$D" ] || { echo "$K 또는 $D가 이미 있습니다. 지우고 다시 하세요"; exit 1; }

echo "== 1. 커널 준비(kernel.org 3.18.24 + 헤더 패치 + 설정)"
mkdir -p "$(dirname "$K")"
tar -xJf "$KTAR" -C "$(dirname "$K")"
cd "$K"
# PINCTRL은 묻는 말이 없는 설정이라 Kconfig에 묻는 말만 붙인다(코드는 안 바꿈)
perl -0pi -e 's/config PINCTRL\n\tbool\n/config PINCTRL\n\tbool "kp: pinctrl"\n/' drivers/pinctrl/Kconfig
bash "$B/scripts/hdr-patch.sh" "$K"
$MK -s vexpress_defconfig
grep -v '^#' "$B/scripts/config.frag" | grep -v '^[[:space:]]*$' | while read -r a b c; do
  if [ -n "$c" ]; then scripts/config "$a" "$b" "$c"; else scripts/config "$a" "$b"; fi
done
$MK -s olddefconfig
cmp .config "$B/tcc897x/kernel.config" && echo "커널 설정: 묶음의 kernel.config와 같음"
$MK -s modules_prepare

echo "== 2. 드라이버(cilynx/rtl88x2bu 04ed7009 + kp-protect 적용본)"
mkdir -p "$(dirname "$D")"
cp -a "$B/tcc897x/rtl88x2bu" "$D"
cd "$D"
bash "$B/scripts/kp-protect.sh" "$D"   # 이미 적용돼 있어 바뀌지 않는다(확인만)
make -s ARCH=arm CROSS_COMPILE=arm-eabi- KSRC=$K KVER=3.18.24-tcc clean >/dev/null 2>&1 || true
make -j8 ARCH=arm CROSS_COMPILE=arm-eabi- KSRC=$K KVER=3.18.24-tcc EXTRA_CFLAGS="-g " > /tmp/driver-build-tcc897x.log 2>&1 \
  || { tail -30 /tmp/driver-build-tcc897x.log; exit 2; }
echo "md5: $(md5sum 88x2bu.ko | cut -d' ' -f1)  (1.8.0 패키지: 4365323f5141ead1714a8c08207b9788)"
