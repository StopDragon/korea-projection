# 니로(tcc897x) 커널에 맞추려는 설정 조각. vexpress_defconfig 위에 얹는다(build.sh의 BASE).
# 바탕 소스는 kernel.org 3.18.24가 가장 가깝다(조사 문서 8장).
# 근거: 순정 모듈 vermagic "3.18.24-tcc SMP preempt mod_unload ARMv7 p2v8", 기호 판 검사 없음,
# cfg80211 내장(리포트). 나머지는 구조체 배치를 견주며 채운다.
-e SMP
-e PREEMPT
-e MODULES
-e MODULE_UNLOAD
-d MODVERSIONS
-e ARM_PATCH_PHYS_VIRT
-e DEBUG_INFO
-e WIRELESS
-e CFG80211
-e CFG80211_WEXT
-e USB
-e USB_SUPPORT
# 1차 대조에서 순정에만 있던 필드: module의 tracepoint·trace_events, sk_buff의 nfct·nf_bridge·tc_index·tc_verd·secmark
-e FTRACE
-e ENABLE_DEFAULT_TRACERS
-e NETFILTER
-e NF_CONNTRACK
-e BRIDGE
-e BRIDGE_NETFILTER
-e NET_SCHED
-e NET_CLS_ACT
-e NETWORK_SECMARK
# 2차: 순정 spinlock이 16바이트, mutex가 36바이트 → 스핀락 디버그가 켜져 있다
-e DEBUG_KERNEL
-e DEBUG_SPINLOCK
# 3차: 순정 timer_list가 52바이트(통계 필드), module의 arch가 0바이트(unwind 표 없음)
-e TIMER_STATS
-d ARM_UNWIND
# 4차: 순정 dev_pm_info에 런타임 전원 필드 없음, device에 cma_area 없음, archdata 4바이트
-d PM_RUNTIME
-d CMA
-d DMA_CMA
-d IOMMU_SUPPORT
# 5차: 순정 device에 pins 필드 있음
-e PINCTRL
# 6차: 순정 sk_buff에 ndisc_nodetype 있음(IPv6 경로 정보). PINCTRL은 묻는 말이 없는 설정이라 build.sh가 Kconfig에 묻는 말을 붙인다
-e IPV6
-e IPV6_ROUTER_PREF
-e IPV6_ROUTE_INFO
-e IPV6_OPTIMISTIC_DAD
# 7차(안드로이드 공용 커널 바탕): 전체 대조에서 순정에만 있던 필드로 맞춘다
# cfg80211_ops.testmode_cmd / cred·file·sock·super_block의 보안·키링 필드 / signal_struct.audit_tty
-e NL80211_TESTMODE
-e SECURITY
-e SECURITY_NETWORK
-e SECURITY_SELINUX
-e KEYS
-e AUDIT
# sched_entity.statistics, sched_rt_entity의 그룹 필드, hrtimer_cpu_base.expires_next
-e SCHEDSTATS
-e SCHED_DEBUG
-e CGROUPS
-e CGROUP_SCHED
-e FAIR_GROUP_SCHED
-e RT_GROUP_SCHED
-e HIGH_RES_TIMERS
# inode.i_acl, zonelist(영역 3개), thread_struct에 디버그 레지스터 없음
-e FS_POSIX_ACL
-e EXT4_FS
-e EXT4_FS_POSIX_ACL
-e TMPFS
-e TMPFS_POSIX_ACL
-e HIGHMEM
-d PERF_EVENTS
-e ARM_THUMBEE
# netns_ipv4.rules_ops, netns_ct의 이벤트·시간 제한, netns_xt, ip6table_security
-e IP_MULTIPLE_TABLES
-e IPV6_MULTIPLE_TABLES
-e NF_CONNTRACK_EVENTS
-e NF_CONNTRACK_TIMEOUT
-e NF_CONNTRACK_IPV4
-e NF_CONNTRACK_IPV6
-e NETFILTER_XTABLES
-e IP_NF_IPTABLES
-e IP6_NF_IPTABLES
-e IP6_NF_SECURITY
-e IP_NF_SECURITY
-e BRIDGE_NF_EBTABLES
-e NF_CONNTRACK_PROC_COMPAT
# 8차: hh_cache 120바이트(WLAN이 헤더 여유를 키움), netns_ct.nat_bysource, cgroup 하위 체계 2개 더
-e WLAN
-e NF_NAT
-e NF_NAT_IPV4
-e CGROUP_CPUACCT
-e CGROUP_FREEZER
# 9차: 남은 15개 가운데 설정으로 맞추는 것
# netns_ipv4.rules_ops(고급 경로 규칙이 꺼져 IP_MULTIPLE_TABLES가 안 켜졌었다), inode.i_blocks 8바이트
-e IP_ADVANCED_ROUTER
-e IP_MULTIPLE_TABLES
-e LBDAF
# 우리 task_struct에만 있던 cpuset·preempt_disable_ip, vm_event_state의 풍선 메모리 통계 3개
-d CPUSETS
-d DEBUG_PREEMPT
-d MEMORY_BALLOON
# pm_subsys_data.domain_data (hdr-patch.sh가 묻는 말을 붙인다)
-e PM_GENERIC_DOMAINS
# 10차: MEMORY_BALLOON은 VIRTIO_BALLOON이 켜서 안 꺼졌었다. cgroup 하위 체계는 cpuset 대신 debug(안드로이드 기본 설정)
-d VIRTIO_BALLOON
-e CGROUP_DEBUG
