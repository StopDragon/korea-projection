#!/bin/bash
# 1.8.0 동글 드라이버 보호 패치(우리가 직접 씀, 2026-11-18). GPL-2.0 원 소스(cilynx/rtl88x2bu) 위에 얹는다. 다른 사람 패치는 가져오지 않았다.
# 쓰는 법: bash kp-protect.sh <드라이버 소스 폴더>   (두 번 돌려도 같음, 들어갔는지 끝에 확인, 원 소스 모양이 다르면 3으로 끝남)
# 니로는 kernel.panic=5·panic_on_oops=1·softlockup_panic=1이라 oops나 CPU 독점 하나면 5초 뒤 재부팅된다. 그래서 "견디기"가 목표다.
# 하는 일:
#  1. 뽑을 때 보호(usb_intf.c rtw_dev_remove): USB 장치가 이미 떨어졌으면(NOTATTACHED) 처음에 뽑힘 표시를 세운다.
#     원래는 네트워크 장치를 먼저 내리고(인터페이스 닫기 → 레지스터 요청) 그 뒤에 표시를 세운다.
#     rmmod는 원래 순서대로 칩을 끄고 내려간다. usbfs로 떼어 냄·장치 리셋(순정 앱의 libusb)은 원래 코드대로 네트워크 장치를 내린 뒤
#     뽑힘 표시를 세워 칩을 끄지 않고 풀린다(리뷰 11-18: 다시 붙을 때 칩 초기화가 실패할 수 있으나 oops는 아님, 차에서 확인할 것).
#  2. 수신 오류 반복 막기(usb_ops_linux.c 수신 완료 두 곳): -EPROTO·-EILSEQ·-ETIME·-ECOMM·-EOVERFLOW면 원래는 인터럽트 문맥에서
#     곧바로 다시 보낸다. 컨트롤러가 즉시 실패를 돌려주면 끝없이 돌아 CPU를 잡을 수 있다(softlockup → 재부팅).
#     장치가 CONFIGURED보다 낮거나(떨어짐·리셋 중, SUSPENDED는 제외) 1초에 200번을 넘으면 다시 보내지 않고 드라이버를 멈춤 표시로 둔다.
#     창은 첫 오류 때 시작한다(리뷰 11-18: 32비트 jiffies는 부팅 뒤 약 5분 동안 음수 쪽에서 시작해 0 기준 창이 열리지 않음).
#     멈춘 뒤에는 동글을 뽑거나 rmmod해야 다시 쓸 수 있다(dmesg에 "kp-protect: rx error loop stopped").
#  3. 기록: rtw_dev_remove 시작·끝, 수신 멈춤, 프로브 시작·결과(실패한 단계 번호)를 printk(KERN_INFO)로 남긴다. modinfo에 kp_protect=4.
#     (11-18 니로 차 결과로 고침: 이 빌드 설정은 CONFIG_RTW_DEBUG=n이라 RTW_PRINT·RTW_INFO가 모두 빈 매크로다. 3판의 표시 줄은 컴파일되지 않았다)
#     프로브 단계: 1 dvobj 준비(usb_dvobj_init), 2 어댑터 준비(칩 읽기), 3 USB 모드 바꾸기, 4 가상 인터페이스, 5 네트워크 장치 등록, 0 성공.
#     MAC·일련번호는 찍지 않는다(단계 번호·반환값·인터페이스 번호만).
#  4. 판 5(11-18 니로 2b: 붙은 채 뽑은 뒤 재부팅으로 보임, 코드 조사 결과로 우리가 씀):
#     - 내릴 때 tasklet 끝내기: rtw_usb_primary_adapter_deinit의 rtw_dev_unload 뒤, 메모리를 풀기 전에 recv·xmit tasklet을 tasklet_kill.
#       쓰기 완료 콜백은 오류 상태에서도 xmit tasklet을 다시 예약하므로, 풀린 메모리에서 돌 수 있었다(인터페이스를 연 적이 있을 때만).
#     - 내리는 중 열기 막기: netdev_open 처음에 내리는 중(processing_dev_remove)이거나 장치가 떨어졌으면(NOTATTACHED) -ENODEV.
#       원래 열기는 뽑힘 표시를 지우고 사라진 장치에 hal_init을 한다.
#     - 기록 더함: netdev 열림("kp-protect: netdev open", 안드로이드가 kpw0을 열었는지 가름), 열기 거절, rtw_dev_remove 안에서
#       네트워크 장치 내림 끝("dev_remove ndev gone")·unload 끝("unload done"). 재부팅 뒤 지난 부팅 기록의 마지막 표시로 어디서 멈췄는지 본다.
# 장치 이름은 드라이버에 이미 있는 모듈 인자(ifname·if2name)로 insmod 때 정한다(코드 바꿈 없음).
set -euo pipefail
D=${1:?드라이버 소스 폴더}
F=$D/os_dep/linux/usb_intf.c
G=$D/os_dep/linux/usb_ops_linux.c
[ -f "$F" ] && [ -f "$G" ] || { echo "kp-protect: 소스 파일 없음" >&2; exit 2; }

if ! grep -q 'kp-protect: unplug' "$F"; then
  perl -0pi -e 's/(static void rtw_dev_remove\(struct usb_interface \*pusb_intf\)\n\{.*?\n\tdvobj->processing_dev_remove = _TRUE;\n)/$1\n\t\/* kp-protect: unplug - USB 장치가 이미 떨어졌으면 내리기 전에 뽑힘 표시를 세워 사라진 장치에 요청을 보내지 않는다.\n\t * rmmod는 원래 순서대로 칩을 끄고, usbfs 떼어 냄·리셋은 원래 코드대로 아래에서 뽑힘 표시를 세운다 *\/\n\tprintk(KERN_INFO "kp-protect: dev_remove start attached=%d\\n", interface_to_usbdev(pusb_intf)->state != USB_STATE_NOTATTACHED);\n\tif (interface_to_usbdev(pusb_intf)->state == USB_STATE_NOTATTACHED)\n\t\trtw_set_surprise_removed(padapter);\n/s' "$F"
  perl -0pi -e 's/(\tRTW_INFO\("-r871xu_dev_remove, done\\n"\);\n)/$1\tprintk(KERN_INFO "kp-protect: dev_remove done\\n");\n/' "$F"
fi
if ! grep -q 'kp-protect: probe' "$F"; then
  # 프로브(rtw_drv_init) 시작·결과 표시. 실패한 곳마다 단계 번호를 정하고 끝(exit:)에서 한 줄 찍는다
  perl -0pi -e 's/(static int rtw_drv_init\(struct usb_interface \*pusb_intf, const struct usb_device_id \*pdid\)\n\{\n\t_adapter \*padapter = NULL;\n\tint status = _FAIL;\n\tstruct dvobj_priv \*dvobj;\n)/$1\tint kp_step = 0; \/* kp-protect: probe 실패 단계 *\/\n/' "$F"
  perl -0pi -e 's/(\t\/\* RTW_INFO\("\+rtw_drv_init\\n"\); \*\/\n)/$1\tprintk(KERN_INFO "kp-protect: probe start if=%d\\n", pusb_intf->cur_altsetting->desc.bInterfaceNumber);\n/' "$F"
  perl -0pi -e 's/(\tdvobj = usb_dvobj_init\(pusb_intf, pdid\);\n\tif \(dvobj == NULL\) \{\n)(\t\tgoto exit;\n)/$1\t\tkp_step = 1;\n$2/' "$F"
  perl -0pi -e 's/(\t\tRTW_INFO\("rtw_usb_primary_adapter_init Failed!\\n"\);\n)(\t\tgoto free_dvobj;\n)/$1\t\tkp_step = 2;\n$2/' "$F"
  perl -0pi -e 's/\tif \(usb_reprobe_switch_usb_mode\(padapter\) == _TRUE\)\n\t\tgoto free_if_prim;\n/\tif (usb_reprobe_switch_usb_mode(padapter) == _TRUE) {\n\t\tkp_step = 3;\n\t\tgoto free_if_prim;\n\t}\n/' "$F"
  perl -0pi -e 's/(\t\t\tRTW_INFO\("rtw_drv_add_iface failed! \(%d\)\\n", i\);\n)(\t\t\tgoto free_if_vir;\n)/$1\t\t\tkp_step = 4;\n$2/' "$F"
  perl -0pi -e 's/\tif \(rtw_os_ndevs_init\(dvobj\) != _SUCCESS\)\n\t\tgoto free_if_vir;\n/\tif (rtw_os_ndevs_init(dvobj) != _SUCCESS) {\n\t\tkp_step = 5;\n\t\tgoto free_if_vir;\n\t}\n/' "$F"
  # 리뷰 11-18 낮음 4: rtw_drv_init 안의 exit:로 묶는다(다른 함수의 같은 꼴에 넣지 않게)
  perl -0pi -e 's/(static int rtw_drv_init\(struct usb_interface \*pusb_intf, const struct usb_device_id \*pdid\)\n\{.*?\nexit:\n)(\treturn status == _SUCCESS \? 0 : -ENODEV;\n)/$1\tprintk(KERN_INFO "kp-protect: probe ret=%d step=%d\\n", status == _SUCCESS ? 0 : -ENODEV, kp_step);\n$2/s' "$F"
fi
O=$D/os_dep/linux/os_intfs.c
[ -f "$O" ] || { echo "kp-protect: os_intfs.c 없음" >&2; exit 2; }
if ! grep -q 'kp-protect: tasklet' "$F"; then
  # 판 5: 내릴 때 tasklet 끝내기(메모리를 풀기 전), unload 끝 표시
  perl -0pi -e 's/(static void rtw_usb_primary_adapter_deinit\(_adapter \*padapter\)\n\{.*?\n\trtw_dev_unload\(padapter\);\n)/$1\n\t\/* kp-protect: tasklet - 쓰기 완료 콜백이 오류 때도 다시 예약하므로 메모리를 풀기 전에 끝낸다 *\/\n\ttasklet_kill(&padapter->recvpriv.recv_tasklet);\n\ttasklet_kill(&padapter->xmitpriv.xmit_tasklet);\n\tprintk(KERN_INFO "kp-protect: unload done\\n");\n/s' "$F"
  # 판 5: rtw_dev_remove 안에서 네트워크 장치 내림이 끝났다는 표시
  perl -0pi -e 's/(\t\/\* TODO: use rtw_os_ndevs_deinit instead at the first stage of driver.s dev deinit function \*\/\n\trtw_os_ndevs_unregister\(dvobj\);\n)(\n\tif \(usb_drv\.drv_registered == _TRUE\) \{)/$1\tprintk(KERN_INFO "kp-protect: dev_remove ndev gone\\n");\n$2/' "$F"
fi
if ! grep -q 'kp-protect: open' "$O"; then
  # 판 5: 내리는 중·떨어진 장치면 열기 거절(원래 열기는 뽑힘 표시를 지운다), 열림 표시
  perl -0pi -e 's/(int netdev_open\(struct net_device \*pnetdev\)\n\{\n\tint ret = _FALSE;\n\t_adapter \*padapter = \(_adapter \*\)rtw_netdev_priv\(pnetdev\);\n\tstruct pwrctrl_priv \*pwrctrlpriv = adapter_to_pwrctl\(padapter\);\n\n\tif \(pwrctrlpriv->bInSuspend == _TRUE\) \{\n.*?\n\t\}\n)/$1\n\t\/* kp-protect: open - 내리는 중이거나 장치가 떨어졌으면 열지 않는다(원래 열기는 뽑힘 표시를 지우고 사라진 장치에 hal_init을 한다) *\/\n\tprintk(KERN_INFO "kp-protect: netdev open\\n");\n#ifdef CONFIG_USB_HCI\n\tif (adapter_to_dvobj(padapter)->processing_dev_remove == _TRUE\n\t    || interface_to_usbdev(adapter_to_dvobj(padapter)->pusbintf)->state == USB_STATE_NOTATTACHED) {\n\t\tprintk(KERN_INFO "kp-protect: open refused\\n");\n\t\treturn -ENODEV;\n\t}\n#endif\n/s' "$O"
fi
if ! grep -q 'kp-protect: version' "$F"; then
  printf '\n/* kp-protect: version - Korea Projection 보호 패치 표시 */\nMODULE_INFO(kp_protect, "5");\n' >> "$F"
fi

if ! grep -q 'kp-protect: rxloop' "$G"; then
  # 도움 함수는 첫 수신 완료 함수(CONFIG_USE_USB_BUFFER_ALLOC_RX 갈래) 앞에 넣는다
  perl -0pi -e 's/(\n#ifdef CONFIG_USE_USB_BUFFER_ALLOC_RX\n)/\n\/* kp-protect: rxloop - 수신 오류 때 곧바로 다시 보내는 것을 1초 200번으로 제한하고, 장치가 CONFIGURED보다 낮으면(떨어짐·리셋 중) 멈춘다(SUSPENDED는 멈추지 않음) *\/\nstatic int kp_rx_err_stop(_adapter *padapter, struct urb *purb)\n{\n\tstatic unsigned long kp_win;\n\tstatic int kp_cnt;\n\tstatic int kp_said;\n\n\tif (purb->dev == NULL || purb->dev->state < USB_STATE_CONFIGURED)\n\t\tgoto stop;\n\tif (kp_cnt == 0 || time_after(jiffies, kp_win + HZ)) {\n\t\tkp_win = jiffies;\n\t\tkp_cnt = 0;\n\t}\n\tif (++kp_cnt <= 200)\n\t\treturn 0;\nstop:\n\tif (kp_said < 3) {\n\t\tkp_said++;\n\t\tprintk(KERN_INFO "kp-protect: rx error loop stopped\\n");\n\t}\n\trtw_set_drv_stopped(padapter);\n\treturn 1;\n}\n$1/' "$G"
  perl -0pi -e 's/(\t\tcase -EOVERFLOW:\n.*?)(\t\t\trtw_read_port\(padapter, precvpriv->ff_hwaddr, 0, \(unsigned char \*\)precvbuf\);\n\t\t\tbreak;\n)/$1\t\t\tif (kp_rx_err_stop(padapter, purb)) \/* kp-protect: rxloop *\/\n\t\t\t\tbreak;\n$2/gs' "$G"
fi

# 확인
grep -q 'kp-protect: unplug' "$F" || { echo "kp-protect: 뽑을 때 보호가 들어가지 않음(원 소스 모양이 다름)" >&2; exit 3; }
grep -q 'kp-protect: dev_remove done' "$F" || { echo "kp-protect: 끝 기록이 들어가지 않음" >&2; exit 3; }
grep -q 'MODULE_INFO(kp_protect, "5");' "$F" || { echo "kp-protect: 표시가 들어가지 않음(옛 판 표시면 원 소스를 새로 받으세요)" >&2; exit 3; }
awk '/^static void rtw_dev_remove\(struct usb_interface \*pusb_intf\)$/ { r = NR } r && /kp-protect: unplug/ && !u { u = NR } r && /rtw_os_ndevs_unregister\(dvobj\);/ && !n { n = NR } END { exit !(r && u && n && u < n) }' "$F" \
  || { echo "kp-protect: 순서가 맞지 않음" >&2; exit 3; }
grep -q 'kp-protect: probe start' "$F" && grep -q 'kp-protect: probe ret=' "$F" || { echo "kp-protect: 프로브 표시가 들어가지 않음(원 소스 모양이 다름)" >&2; exit 3; }
[ "$(grep -c 'kp_step = [1-5];' "$F")" = 5 ] && grep -q 'int kp_step = 0;' "$F" || { echo "kp-protect: 프로브 단계 표시가 다섯 곳에 들어가지 않음(원 소스 모양이 다름)" >&2; exit 3; }
! grep -q 'RTW_PRINT("kp-protect' "$F" "$G" || { echo "kp-protect: 옛 판(RTW_PRINT) 표시가 남음, 원 소스를 새로 받으세요" >&2; exit 3; }
grep -q 'kp-protect: unload done' "$F" && [ "$(grep -c 'tasklet_kill(&padapter->' "$F")" = 2 ] || { echo "kp-protect: tasklet 끝내기가 들어가지 않음(원 소스 모양이 다름)" >&2; exit 3; }
grep -q 'kp-protect: dev_remove ndev gone' "$F" || { echo "kp-protect: ndev 표시가 들어가지 않음" >&2; exit 3; }
grep -q 'kp-protect: open refused' "$O" && grep -q 'kp-protect: netdev open' "$O" || { echo "kp-protect: 열기 막기가 들어가지 않음(원 소스 모양이 다름)" >&2; exit 3; }
awk '/^static void rtw_usb_primary_adapter_deinit\(_adapter \*padapter\)$/ { r = NR } r && /rtw_dev_unload\(padapter\);/ && !u { u = NR } r && /tasklet_kill\(&padapter->xmitpriv/ && !t { t = NR } r && /rtw_free_drv_sw\(padapter\);/ && !f { f = NR } END { exit !(r && u && t && f && u < t && t < f) }' "$F" || { echo "kp-protect: tasklet 끝내기 순서가 맞지 않음" >&2; exit 3; }
grep -q '^static int kp_rx_err_stop(' "$G" || { echo "kp-protect: 수신 보호 함수가 들어가지 않음" >&2; exit 3; }
[ "$(grep -c 'if (kp_rx_err_stop(padapter, purb))' "$G")" = 2 ] || { echo "kp-protect: 수신 보호가 두 곳에 들어가지 않음" >&2; exit 3; }
echo "kp-protect: 적용됨 ($F, $G, $O)"
